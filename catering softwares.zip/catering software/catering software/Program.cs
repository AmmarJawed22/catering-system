using catering_software.Context;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<myContext>(options =>
options.UseSqlServer(
builder.Configuration.GetConnectionString("con")));
builder.Services.AddMvc();  


var app = builder.Build();

app.MapControllerRoute(
    name: "default",
    pattern:"{controller=Admin}/{action=Index}"
    );
app.UseStaticFiles();   
app.Run();
