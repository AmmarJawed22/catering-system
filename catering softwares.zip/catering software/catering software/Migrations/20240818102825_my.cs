﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace catering_software.Migrations
{
    /// <inheritdoc />
    public partial class my : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbl_admin",
                columns: table => new
                {
                    Admin_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Admin_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Admin_email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Admin_password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_admin", x => x.Admin_id);
                });

            migrationBuilder.CreateTable(
                name: "tbl_daigs",
                columns: table => new
                {
                    Daig_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Daig_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Daig_description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Daig_quantity = table.Column<int>(type: "int", nullable: false),
                    Daig_status = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbl_daigs", x => x.Daig_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbl_admin");

            migrationBuilder.DropTable(
                name: "tbl_daigs");
        }
    }
}
