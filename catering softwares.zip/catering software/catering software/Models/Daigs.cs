﻿using System.ComponentModel.DataAnnotations;

namespace catering_software.Models
{
    public class Daigs
    {
        [Key]
        public int Daig_id { get; set; }
        public string Daig_name { get; set; }
        public string Daig_description { get; set; }
        public int Daig_quantity { get; set; }
        public string Daig_status {  get; set; }    
    }
}
