﻿using catering_software.Context;
using catering_software.Models;
using Microsoft.AspNetCore.Mvc;

namespace catering_software.Controllers
{
    public class AdminController : Controller
    {
        private readonly myContext _context;

        public AdminController(myContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.tbl_daigs.ToList());
        }

        public IActionResult AddDaig()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddDaig(Daigs daig)
        {
            if (ModelState.IsValid)
            {
                _context.tbl_daigs.Add(daig);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(daig);
        }

        public IActionResult UpdateDaig(int id)
        {
            var daig = _context.tbl_daigs.Find(id);
            if (daig == null)
            {
                return NotFound();
            }
            return View(daig);
        }

        [HttpPost]
        public IActionResult UpdateDaig(Daigs daig)
        {
            if (ModelState.IsValid)
            {
                _context.tbl_daigs.Update(daig);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(daig);
        }

        public IActionResult DeleteDaig(int id)
        {
            var daig = _context.tbl_daigs.Find(id);
            if (daig == null)
            {
                return NotFound();
            }
            return View(daig);
        }

        [HttpPost, ActionName("DeleteDaig")]
        public IActionResult DeleteConfirmed(int id)
        {
            var daig = _context.tbl_daigs.Find(id);
            if (daig != null)
            {
                _context.tbl_daigs.Remove(daig);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
