﻿using catering_software.Models;
using Microsoft.EntityFrameworkCore;

namespace catering_software.Context
{
    public class myContext : DbContext
    {
        public myContext(DbContextOptions<myContext> options)
            : base(options)
        {
            
        }
        public DbSet<Admin> tbl_admin { get; set; }
        public DbSet<Daigs> tbl_daigs { get; set; } 
    }
}
